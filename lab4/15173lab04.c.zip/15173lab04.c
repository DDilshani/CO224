#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define RESET		0
#define BRIGHT 		1

#define BLACK 		0
#define RED		1
#define GREEN		2
#define YELLOW		3
#define BLUE		4
#define MAGENTA		5
#define CYAN		6
#define	WHITE		7

void textcolor(int attr, int fg, int bg);

void textcolor(int attr, int fg, int bg)
{	char command[13];

	sprintf(command, "%c[%d;%d;%dm", 0x1B, attr, fg + 30, bg + 40);
	printf("%s", command);
}


void checker(int color[]){
	int mainRow,row,col,i=0,j;
	for(mainRow=0; mainRow<8; mainRow++){
		for(row=0; row<8; row++){
			for(col=0; col<8; col++){
				textcolor(BRIGHT,color[i],color[i]);
				for(j=0; j++<8; printf(" ")){
				}
				i=1-i;
			}
				textcolor(RESET,color[1],color[0]);
            printf("\n");
		}
		i=1-i;
	}
}


void donut(int color[], int diameter){
	float radius=(float)diameter/2;

    int x,y;
    for(x=-radius;x<radius;x++){
        for(y=-radius;y<radius;y++){

            if(x*x+y*y<radius*radius && x*x+y*y>radius*radius/4){
                textcolor(BRIGHT,color[0],color[1]);
                printf(" ");
            }else{
                textcolor(RESET,color[1],color[0]);
                printf(" ");
            }

        }
        textcolor(RESET,color[0],color[0]);
        printf("\n");
    }
}

int check(char *col){
    if(strcmp(col,"black")==0)return 0;
    else if(strcmp(col,"red")==0)return 1;
    else if(strcmp(col,"green")==0)return 2;
    else if(strcmp(col,"yellow")==0)return 3;
    else if(strcmp(col,"blue")==0)return 4;
    else if(strcmp(col,"magenta")==0)return 5;
    else if(strcmp(col,"cyan")==0)return 6;
    else if(strcmp(col,"white")==0)return 7;
    else return -1;
}

int main(int argc, char **argv){

int color[]={check(argv[2]),check(argv[3])};


if(argc<4){
	printf("Not enough arguments\n");
	return 0;
}else if(argc>4){
	printf("Too many arguments\n");
	return 0;
}


int bg=color[0];
int fg=color[1];

if(bg<0){
	printf("Background color is not available\n");
	return 0;
}
if(fg<0){
	printf("Foreground color is not available\n");
	return 0;
}



if(strcmp(argv[1],"checker")==0){
	checker(color);
}else if(strcmp(argv[1],"donut")==0){
        int diameter;
        int ret_val=scanf("%d",&diameter); //check the invalid inputs
        if(ret_val!=1)return 0;
        donut(color,diameter);
}else{
        printf("Requested figure is not available\n");
		return 0;
}


	textcolor(RESET, WHITE, BLACK);
	return 0;
}
