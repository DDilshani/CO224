#include <stdio.h>

int main()
{
 int n;
 float x=0;
 float y=0;
 float float_n;
 float bill=0;
 printf("enter the monthly units \n");
 int a=scanf("%f", &float_n);
 n=(int)float_n;

if (n<0 | a==0 | n<float_n){
printf("-1");
return 0;
}else {
     if (n<=60){
        if (n<=30){
            x=30;
            y=2.50*n;
        }
        else {
            x=60+(2.50*30);
            y=(n-30)*4.85;
        }
     }else if (n<=90){
        x=90+7.85*60;
        y=10*(n-60);
     }else if (n<=120){
         x=480+10*30+7.85*30;
         y=27.75*(n-90);
     }else if (n<=180){
        x=480+27.75*30+10*30+7.85*60;
        y=32*(n-120);
     }else {
        x=540+32*60+27.75*30+10*30+7.85*60;
        y=45*(n-180);
     }
     }
bill=x+y;
printf("Bill is %.2f\n",bill);
return 0;
}
