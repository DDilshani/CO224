#include<stdio.h>
#include<string.h>
int main(){

char a;//declare the fist letter of the input for the player1
char b;//declare the second letter of the input for the player2


scanf("%c %c",&a,&b); //get a combination from the user as two characters    




/*check for wrong inputs. If the inputs are not R or L or S or P or C
the input is wrong.*/


//check a
if (!((a=='R') || (a=='L') || (a=='S') || (a=='P') || (a=='C'))) {
	printf("Wrong input\n");


//check b
}else if(! ((b=='R') || (b=='L') || (b=='S') || (b=='P') || (b=='C'))) {    
	printf("Wrong input\n");



}else{

//check for ties.If the combination is equal (RR or LL or PP or CC or SS) the game will tie.
	if (a==b){
		printf("Tie\n");
	}else{

		//check winner
		if  ((a=='S'&& b=='R') ||  (a=='L'&& b=='S') ||  (a=='S'&& b=='C') ||  (a=='P'&& b=='S') ||  (a=='R'&& b=='C')){
			printf("Player 1 wins\n");

		
		}else if  ((a=='C'&& b=='L') ||  (a=='C'&& b=='P') ||  (a=='P'&& b=='R') ||  (a=='L'&& b=='P') ||  (a=='R'&& b=='L')){
			printf("Player 1 wins\n");


		}else{
			printf("Player 2 wins\n");
		}
	}
}



return 0;
}
