// Week10_Pow.c
// Compute the nth power of x, where
// n is a non-negative integer.
#include <stdio.h>

double mypow(double, int);

int main(void) {
	double x;
	int n;

	printf("Enter x and n: ");
	scanf("%lf %d", &x, &n);

	if(n>=0){ // n should be a non-negative number
		printf("mypow(%f, %d) = %f\n", x, n, mypow(x, n));
	}
	return 0;
}

// Compute the nth power of x.
// Precond: n >= 0
double mypow(double x, int n) {
	// to be completed
	double num;
	if(n!=0){
		num=x*mypow(x,n-1);
		return num;
	}else {
		return 1;
	}
}
