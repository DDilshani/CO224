#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define RESET		0
#define BRIGHT 		1

#define BLACK 		0
#define RED		1
#define GREEN		2
#define YELLOW		3
#define BLUE		4
#define MAGENTA		5
#define CYAN		6
#define	WHITE		7

void textcolor(int attr, int fg, int bg);
void textcolor(int attr, int fg, int bg)
{	char command[13];

	sprintf(command, "%c[%d;%d;%dm", 0x1B, attr, fg + 30, bg + 40);
	printf("%s", command);
}



int check(char *col);
void checker(int color[]);
void donut(int color[], int diameter);



//command line arguments
int main(int argc, char **argv){

	int color[]={check(argv[2]),check(argv[3])};//putting background and foreground color


	//check number of inputs
	if(argc<4){
		printf("Not enough arguments\n");
		return 0;
	}else if(argc>4){
		printf("Too many arguments\n");
		return 0;
	}


	//extract background color and foreground color
	int bg=color[0];
	int fg=color[1];


	//check available colors
	if(bg<0){
		printf("Background color is not available\n");
		return 0;
	}
	if(fg<0){
		printf("Foreground color is not available\n");
		return 0;
	}


	//check wheather to draw the checkboard or the donut
	if(strcmp(argv[1],"checker")==0){
		checker(color);//draw the checkboard
	}else if(strcmp(argv[1],"donut")==0){
		int diameter;
		int ret_val=scanf("%d",&diameter); //check the invalid inputs
		if(ret_val!=1)return 0;
		donut(color,diameter);//draw the donut
	}else{
		printf("Requested figure is not available\n");
			return 0;
	}
		textcolor(RESET, WHITE, BLACK);// reset color
		return 0;
}



//function for checker board 8*8
void checker(int color[]){
	int mainRow,row,col,reset=0,space;
	for(mainRow=0; mainRow<8; mainRow++){
		for(row=0; row<8; row++){
			for(col=0; col<8; col++ ){
				textcolor(BRIGHT,color[reset],color[reset]);//print spaces filled with color i
				for(space=0; space++<8; printf(" ")){
				}
				reset=1-reset;
			}
			textcolor(RESET,color[1],color[0]);//reset color
           		printf("\n");//to start a new line
		}
		reset=1-reset;// change the color in the rows
	}
}



//function for the donut
void donut(int color[], int diameter){
int radius=(int)diameter/2;

int x,y;
	for(x=-radius;x<radius;x++){
		for(y=-radius;y<radius;y++){
			if(x*x+y*y<radius*radius && x*x+y*y>radius*radius/4){//for the circle
				textcolor(BRIGHT,color[0],color[1]);
				printf(" ");// print spaces with the color
			}else{
				textcolor(RESET,color[1],color[0]);
				printf(" ");// print spaces with the color
			}
		}
		textcolor(RESET,color[0],color[0]);//rest color
		printf("\n");//to start a new line
	}
}

//return values for the color
int check(char *col){
    if(strcmp(col,"black")==0)return 0;
    else if(strcmp(col,"red")==0)return 1;
    else if(strcmp(col,"green")==0)return 2;
    else if(strcmp(col,"yellow")==0)return 3;
    else if(strcmp(col,"blue")==0)return 4;
    else if(strcmp(col,"magenta")==0)return 5;
    else if(strcmp(col,"cyan")==0)return 6;
    else if(strcmp(col,"white")==0)return 7;
    else return -1;
}

